BUGado em CORS

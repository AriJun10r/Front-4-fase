Este pequeno teste tem um header com navbar e o conteúdo abaixo.

Tem ainda um background de svg pattern da https://app.haikei.app/



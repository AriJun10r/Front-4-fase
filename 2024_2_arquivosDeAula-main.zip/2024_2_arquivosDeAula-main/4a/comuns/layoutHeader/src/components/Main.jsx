
import './Main.css'

function Main() {
  return (
    <main className="main">
        <p>Conteúdo principal que vai crescer automaticamente...</p>

        {/* Adicione mais conteúdo aqui */}
    </main>
  )
}

export default Main

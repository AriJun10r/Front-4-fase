import './index.css'

function Navbar() {
  return (
    <div className='navbar-container'>
      <h1>Taylor Script</h1>
    </div>
  )
}

export default Navbar

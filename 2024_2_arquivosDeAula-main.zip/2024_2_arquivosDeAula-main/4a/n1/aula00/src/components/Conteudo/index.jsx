import './index.css'
function Conteudo() {
  return (
    <div className="conteudo-container">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatem quasi inventore et sunt autem excepturi. Architecto, suscipit iste et dignissimos unde alias eveniet sapiente, mollitia ex ut reprehenderit, eius ipsam!</p>
    </div>
  )
}

export default Conteudo

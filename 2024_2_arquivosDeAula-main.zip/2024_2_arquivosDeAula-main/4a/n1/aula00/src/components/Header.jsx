import './Header.css'

function Header() {
  return (
    <div className="header-container">
        <h1>Página bonita</h1>
    </div>

  )
}

export default Header
